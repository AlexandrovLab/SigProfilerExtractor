
# THIS FILE IS GENERATED FROM SIGPROFILEREXTRACTOR SETUP.PY
short_version = '1.0.10'
version = '1.0.10'
Update = 'Heirarchy option deleted, clustering deleted and signatures orders by the mutation burden'
    
    