
# THIS FILE IS GENERATED FROM SIGPROFILEREXTRACTOR SETUP.PY
short_version = '1.0.13.7'
version = '1.0.13.7'
Update = 'Heirarchy option deleted, clustering deleted and signatures orders by the mutation burden'
    
    