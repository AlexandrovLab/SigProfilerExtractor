
# THIS FILE IS GENERATED FROM SIGPROEXTRACTOR SETUP.PY
short_version = '0.0.5.61'
version = '0.0.5.61'
    
    